#!/bin/sh
while [ 1 ]
do
        pid_app=$(pidof iWaveOBD2FW)
        echo "######################### PID $pid_app ###########################
        if [ -z $pid_app ]
        then
                i2cset -f -y 1 0x6b 0x07 0x6c
                i2cset -f -y 1 0x6b 0x07 0x6c
                sleep 1
                i2cset -f -y 1 0x6b 0x07 0x6c
                sleep 1
                i2cset -f -y 1 0x6b 0x07 0x6c
                sleep 5
                echo 1 > /sys/class/gpio/gpio137/value
        fi
done

