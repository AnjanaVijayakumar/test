#!/bin/sh
file_tmp=/home/root/obd.txt
file=/home/root/file.txt
dd if=/dev/zero of=$file_tmp bs=1M count=10
while [ 1 ];
do
	if [ -e "$file_tmp" ]
	then
		cp $file_tmp $file
		if [ "$?" = "0" ]; 
		then
			echo "Transfered Successfully"
			if cmp -s "$file" $file;
			then
				echo "NAND operation Success"
				rm -r $file
			else
				echo "NAND operation Failed"
				rm -r $file
			
			fi
		else
			echo "Transfer failed"	                                          
		fi
	else 
		echo "file not found"
		dd if=/dev/zero of=$file_tmp bs=1M count=10
		exit           
	fi
done
