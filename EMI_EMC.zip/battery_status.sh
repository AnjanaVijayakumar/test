#!/bin/sh
echo "Please make sure that battery is connected"
while [ 1 ];
do
val=$(cat /sys/class/gpio/gpio118/value)
if [ "$val" = 1 ]
then
        echo "Battery is fully charged"
elif [ "$val" = 0 ]
then
        echo " Battery is charging "
else
        echo " Invalid value "
fi
done
