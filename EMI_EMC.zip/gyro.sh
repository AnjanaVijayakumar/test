#!/bin/sh
while [ 1 ];
do
gx=$(( $( i2cget -f -y 1 0x6a 0x22 ) << 8 | $( i2cget -f -y 1 0x6a 0x23 ) ))
gy=$(( $( i2cget -f -y 1 0x6a 0x24 ) << 8 | $( i2cget -f -y 1 0x6a 0x25 ) ))
gz=$(( $( i2cget -f -y 1 0x6a 0x26 ) << 8 | $( i2cget -f -y 1 0x6a 0x27 ) ))
echo "Gyro_X $gx Gyro_Y $gy Gyro_Z $gz"
done
