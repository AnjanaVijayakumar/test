echo 0 > /sys/class/gpio/gpio88/value
sleep 1
echo 1 > /sys/class/gpio/gpio88/value
sleep 1
echo 0 > /sys/class/gpio/gpio88/value
sleep 1
insmod /usb/udc-core.ko
insmod /usb/libcomposite.ko
insmod /usb/ci_hdrc.ko
insmod /usb/usbmisc_imx.ko
insmod /usb/ci_hdrc_imx.ko
insmod /usb/u_serial.ko
sleep 1
