
echo 0 > /sys/class/gpio/gpio137/value
echo 1 > /sys/class/gpio/gpio90/value
echo 1 > /sys/class/gpio/gpio78/value
