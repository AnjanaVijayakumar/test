#!/bin/sh
while [ 1 ];
do
ax=$(( $( i2cget -f -y 1 0x6a 0x28 ) << 8 | $( i2cget -f -y 1 0x6a 0x29 ) ))
ay=$(( $( i2cget -f -y 1 0x6a 0x2A ) << 8 | $( i2cget -f -y 1 0x6a 0x2B ) ))
az=$(( $( i2cget -f -y 1 0x6a 0x2C ) << 8 | $( i2cget -f -y 1 0x6a 0x2D ) ))
echo "Acc_X $ax Acc_Y $ay Acc_Z $az"
done

