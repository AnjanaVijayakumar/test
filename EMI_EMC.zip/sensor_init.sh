#Acc Init
echo 1 > /sys/bus/iio/devices/iio\:device1/scan_elements/in_accel_x_en
echo 1 > /sys/bus/iio/devices/iio\:device1/scan_elements/in_accel_y_en
echo 1 > /sys/bus/iio/devices/iio\:device1/scan_elements/in_accel_z_en
echo 1 > /sys/bus/iio/devices/iio\:device1/buffer/enable
i2cset -f -y 1 0x6a 0x10 0x60
i2cset -f -y 1 0x6a 0x59 0x89
i2cset -f -y 1 0x6a 0x5A 0x06
i2cset -f -y 1 0x6a 0x5B 0x00
i2cset -f -y 1 0x6a 0x5E 0x40
i2cset -f -y 1 0x6a 0x0d 0x01
i2cset -f -y 1 0x6a 0x58 0x0e
#Gyro Init
echo 1 > /sys/bus/iio/devices/iio\:device2/scan_elements/in_anglvel_x_en
echo 1 > /sys/bus/iio/devices/iio\:device2/scan_elements/in_anglvel_y_en
echo 1 > /sys/bus/iio/devices/iio\:device2/scan_elements/in_anglvel_z_en
echo 1 > /sys/bus/iio/devices/iio\:device2/buffer/enable
i2cset -f -y 1 0x6a 0x11 0x60
